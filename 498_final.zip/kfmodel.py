import numpy as np

###YOUR CODE HERE###
#motion model
A = np.eye(2)
B = np.mat('1.5,0.1;0.2,-0.5')

#sensor model
C = np.mat('1.05,0.01;0.01,0.9')

#motion noise covariance
R = np.mat([[2.50696845e-03, 1.79957758e-05], [1.79957758e-05,
                                               2.51063277e-03]])

#sensor noise covariance
Q = np.mat([[0.04869528, -0.0058636], [-0.0058636, 1.01216104]])