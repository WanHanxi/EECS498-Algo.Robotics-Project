# Usage

```shell
pip install -r requirements.txt
python run.py
```
