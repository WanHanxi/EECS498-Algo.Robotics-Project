import run as run
# import run2 as particle

print("Kalman Filter: expected time to run: less than 10s")

run.main(1)

print("Particle Filter: expected time to run: less than 30s")

run.main(0)